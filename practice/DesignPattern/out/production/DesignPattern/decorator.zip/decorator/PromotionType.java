package decorator;

public enum PromotionType {
    TrueMove, TrueVision, TrueHighSpeedInternet
}
