package decorator;

public abstract class TruePackage {
    public abstract String getName();
    public abstract double getPrice();
    public abstract int getPrivilege();
    public abstract double getTotalPrice();
}
